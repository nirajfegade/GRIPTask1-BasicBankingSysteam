
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="all.css" />  
    </head>
    <title>Page (Home)</title>
       <style>
    button
  {            
          color: white;
          font-size: 45px;
          font-weight: normal;
          font-family: 'Times New Roman', Times, serif;
          border: 1px solid;
          background-color: #2bab0d;
          width: 400px;
          height: 80px;
          padding: unset;

               
  }

  
    </style>
    <body>
        <header>
            <b>Basic Banking Systeam</b>
        </header>
        <div class="menu-bar">
        <ul>
            <li class="active" ><a href="page1.php">Home</a></li>
            <li><a href="page2.php">Contact</a></li>
            <li><a href="">About</a></li>
           
        </ul>
        </div>

        <pre style="align-items: center;">


                                                         <a href="page4.php">   <button > Transaction </button></a>
                                                            
                                                                
                                                        <a href="page5.php">    <button > Transaction History </button></a>


                                                        <a href="page6.php">    <button > All Customer Details </button></a>
            
    </p>
    </pre>
    <footer>Developed By </footer>
     <footer>Niraj Fegade</footer>
    </body>
</html> 
